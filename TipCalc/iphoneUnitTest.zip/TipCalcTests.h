//
//  TipCalcTests.h
//  TipCalc
//
//  Created by Lee Lundrigan on 2/16/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
//  See Also: http://developer.apple.com/iphone/library/documentation/Xcode/Conceptual/iphone_development/135-Unit_Testing_Applications/unit_testing_applications.html

#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>
#import "TipCalculator.h"


@interface TipCalcTests : SenTestCase {

}

- (void) testTipCalculation;              // simple standalone test

@end   