//
//  TipCalcViewController.h
//  TipCalc
//
//  Created by Lee Lundrigan on 2/16/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TipCalcViewController : UIViewController {

}

@end

